from flask import Flask, render_template, request, redirect, url_for, flash
from flask_mysqldb import MySQL
app=Flask(__name__)
app.secret_key = 'Secrect Key'

app.config['MYSQL_HOST']='localhost'
app.config['MYSQL_USER']='root'
app.config['MYSQL_PASSWORD']=''
app.config['MYSQL_DB']='crud'

db=MySQL(app)


def __init__(self,name,email,phone):
    self.name=name
    self.email=email
    self.phone=phone





@app.route('/')
def index():
    cursor=db.connection.cursor()
    cursor.execute("select * from data")
    data=cursor.fetchall()
    cursor.close()
    return render_template('index.html', employees = data)


@app.route('/insert',methods=['POST'])
def insert():
  if request.method=='POST': 
    name=request.form['name']  
    email=request.form['email']  
    phone=request.form['phone'] 

    cursor=db.connection.cursor()
    dt=" INSERT into data(name,email,phone) values('"+name+"','"+email+"','"+phone+"')"
    cursor.execute(dt)
    db.connection.commit()

    flash("Employee Inserted Successfully")
    return redirect(url_for('index'))

@app.route("/update", methods=['POST','GET'])
def update():
    if request.method=='POST':
      id_data=request.form['id']
      name=request.form['name']  
      email=request.form['email']  
      phone=request.form['phone'] 
      cursor=db.connection.cursor()  
    cursor.execute("" " UPDATE data SET name='"+name+"',email='"+email+"',phone='"+phone+"' WHERE id='"+id_data+"'  " "")
    flash("data updated sucessfully")
    db.connection.commit()
    return redirect(url_for('index'))

@app.route("/delete/<string:id_data>", methods=['POST','GET'])
def delete(id_data):
 
    cursor=db.connection.cursor()  
    cursor.execute("" " delete from data  WHERE id='"+id_data+"'  " "")
    flash("employee deleted sucessfully")
    db.connection.commit()
    return redirect(url_for('index'))

if __name__=='__main__':
    app.run(debug=True)
